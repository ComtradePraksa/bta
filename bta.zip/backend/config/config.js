module.exports = {
  dbConfig: {
    host: 'remotemysql.com',
    user: 'Gu3wYk28LK',
    password: '9EVqUde3cW',
    database: 'Gu3wYk28LK',
    connectionLimit: 100,
    debug: false
  }
};